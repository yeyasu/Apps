//
//  SHDPhotoPreviewViewController.h
//  CameraAppTemplate
//
//  Created by Sergey Grischyov on 07.03.16.
//  Copyright © 2016 ShadeApps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHDPhotoPreviewViewController : UIViewController

@property UIImage *sourceImage;

@end
