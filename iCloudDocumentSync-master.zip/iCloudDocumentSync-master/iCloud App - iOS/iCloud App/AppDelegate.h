//
//  AppDelegate.h
//  iCloud App
//
//  Created by iRare Media on 11/8/13.
//  Copyright (c) 2015 iRare Media. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
