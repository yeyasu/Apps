//
//  SHDNavigationViewController.h
//  timewebmail
//
//  Created by Sergey Grischyov on 15.07.15.
//  Copyright (c) 2015 ShadeApps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHDNavigationViewController : UINavigationController

@end
