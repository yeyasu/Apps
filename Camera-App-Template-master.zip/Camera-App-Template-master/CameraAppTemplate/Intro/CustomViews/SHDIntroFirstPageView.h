//
//  SHDIntroFirstPageView.h
//  CameraAppTemplate
//
//  Created by Sergey Grischyov on 07.03.16.
//  Copyright © 2016 ShadeApps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHDIntroFirstPageView : UIView
@property (weak, nonatomic) IBOutlet UIView *container;

@end
