//
//  ViewController.h
//  CameraAppTemplate
//
//  Created by Sergey Grischyov on 17.02.16.
//  Copyright © 2016 ShadeApps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHDIntroViewController : UIViewController

@end